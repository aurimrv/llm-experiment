int main (void) {  
}
